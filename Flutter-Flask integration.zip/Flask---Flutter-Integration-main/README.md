# Flask-Flutter-Integration

This project involves combinging a flutter app and a flask website hosted on docker.
This works by running the flutter app locally and the flask on a cloud based service. In this project we will be using Googles cloud based service.

Working:
1. Run the flutter app in Visual Studio 
2. select the image we want to classify
3. the image is sent to the flask where classification happens and the result is sent back to flutter
4. The output is shown in the flutter app.

   

https://github.com/Anirudh2465/Flask---Flutter-Integration/assets/110315983/a53e962f-7b9f-4793-9d05-145655309017

GCP : https://cat-dog-classifier-using-flask-xisi3zlsna-el.a.run.app/upload

h5 model link: https://huggingface.co/spaces/Sa-m/Dogs-vs-Cats/blob/main/best_model.h5

docker image link: https://hub.docker.com/r/varrier0903/flask_docker
